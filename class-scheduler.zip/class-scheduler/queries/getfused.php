<?php
include('../functions/db_connect.php');

if (isset($_GET['checkgetfused'])) {

    $id = $_GET['checkgetfused'];

    $query = $connect->query("SELECT * FROM merged_classes where schedule_id = '$id'");

    $data = [];

    while ($row = $query->fetch_assoc()) {
        array_push($data, $row['course']);
    }

    echo json_encode($data);
}

if (isset($_GET['checkgetfusedshs'])) {


    $data = [];

    echo json_encode($data);
}

// if (isset($_GET['mergedfrom'])) {
//     $id = $_GET['mergedfrom'];

//     $query = $connect->query("SELECT scheduled_classes.course as course FROM scheduled_classes join merged_classes where scheduled_classes.schedule_id = merged_classes.schedule_id and merged_classes.merged_id = '$id'")->fetch_assoc();

//     "Merged from: " . $query['course'];
// }
