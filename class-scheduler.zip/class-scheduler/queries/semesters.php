
<?php include('../functions/db_connect.php');

$semesters = mysqli_query($connect, "SELECT * FROM subjects order by semester");
$semesterArr = array();

while ($semesterrow = mysqli_fetch_assoc($semesters)) {
    if (count($semesterArr) === 0) {
        array_push($semesterArr, $semesterrow['semester']);
    } else if ($semesterrow['semester'] === $semesterArr[count($semesterArr) - 1]) {
        $semesterArr[count($semesterArr) - 1] = $semesterrow['semester'];
    } else {
        array_push($semesterArr, $semesterrow['semester']);
    }
}
?>