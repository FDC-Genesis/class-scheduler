
<?php
include('../functions/db_connect.php');

$query = mysqli_query($connect, "SELECT max(member_id) as id FROM members");

$row = $query->fetch_array();

$id = $row['id'];
?>