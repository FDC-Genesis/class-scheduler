<?php
include('../functions/db_connect.php');

if (isset($_GET['getupdateinfo'])){
    $id = $_GET['getupdateinfo'];
    $result = mysqli_query($connect, "SELECT * FROM members where member_id = '$id'");
    $resultArr = array();

    $row = $result->fetch_assoc();
    array_push($resultArr, $row);

    echo json_encode($resultArr);
}
?>