<?php

include('../functions/db_connect.php');

if (isset($_GET['description'])) {

    $id = $_GET['description'];

    $result = mysqli_query($connect, "SELECT description FROM subjects where subject_id = '$id'");
    if (mysqli_num_rows($result) === 0) {
        echo json_encode("No subjects found");
    } else {
        $result = $result->fetch_assoc();
        $result = $result['description'];
        echo json_encode($result);
    }
}
