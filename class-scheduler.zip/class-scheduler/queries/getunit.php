
<?php
include('../functions/db_connect.php');

if (isset($_GET['subject'])) {
    $subject = $_GET['subject'];

    $result = mysqli_query($connect, "SELECT * from subjects where subject_id = '$subject'");

    $resultArr = array();
    $getunit = mysqli_fetch_assoc($result);
    array_push($resultArr, $getunit['units']);

    echo json_encode($resultArr);
}
?>