
<?php

include('../functions/db_connect.php');

$courses = mysqli_query($connect, "SELECT * FROM subjects group by course_id order by course_id");
$courseArr = array();

while ($courserow = mysqli_fetch_assoc($courses)) {
    array_push($courseArr, $courserow['course_id']);
}
// echo json_encode($courseArr);
?>