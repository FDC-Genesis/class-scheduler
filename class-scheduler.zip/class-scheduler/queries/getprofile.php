<?php

include('../functions/login.php');

// $id = $_SESSION['id'];
// $query = mysqli_query($connect, "SELECT * FROM member WHERE member_id = '$id'");

// $row = mysqli_fetch_array($query);

// $name = $row['member_salut'] . " " . $row['member_first'] . " " . $row['member_last'];
