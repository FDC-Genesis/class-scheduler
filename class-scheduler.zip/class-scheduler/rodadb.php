<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
            </tr>
        </thead>
        <tbody>
            <?php $result = mysqli_query(mysqli_connect('localhost', 'ascblzri_havenseeker_root', 'nadiathesisP@$$', 'ascblzri_havenseeker'), "SELECT * FROM user_db");
            while ($row = $result->fetch_assoc()) {
            ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['username'] ?></td>
                    <td><?= $row['password'] ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>