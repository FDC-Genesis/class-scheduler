<?=
"Error, failed to connect to database.";
?>