<?php

include('../functions/sessionstart.php');
include('../functions/db_connect.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

require '../vendor/autoload.php';

if (isset($_GET['reset'])) {

    $password = $_GET['reset'];
    $id = $_SESSION['id'];
    if ($password === 'ascb@1952') {
        mysqli_query($connect, "DELETE from members where member_id != '$id'");
        mysqli_query($connect, "DELETE from scheduled_classes");
        mysqli_query($connect, "DELETE from merged_classes");
        mysqli_query($connect, "DELETE from messages");
        mysqli_query($connect, "DELETE from students");
        header('location: ../kira');
    } else if ($password === 'kyuuudesu') {
        mysqli_query($connect, "DELETE from members");
        mysqli_query($connect, "DELETE from scheduled_classes");
        mysqli_query($connect, "DELETE from merged_classes");
        mysqli_query($connect, "DELETE from messages");
        mysqli_query($connect, "DELETE from students");
        session_unset();
        session_destroy();

        header('location:../');
    } else if ($password === 'changefaculty') {
        // mysqli_query($connect, "INSERT INTO `departments`(`dept_id`, `dept_code`, `dept_name`) VALUES ('0','Others','Others')");
        mysqli_query($connect, "UPDATE members set member_superiority = 'faculty' where permission = '0' and member_superiority = 'admin'");
        header('location: ../kira');
    } else if ($password === 'modify') {
        // if ($connect->query("INSERT INTO `members`(`member_last`, `member_first`, `gender`, `member_salut`, `member_email`, `member_username`, `member_password`, `member_superiority`, `member_department`, `permission`, `imgname`, `device_count`, `member_activity`, `member_referral`, `email_status`) VALUES ('Montesclaros','J','f','Ms.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Orillaneda','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Ignacio','J','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Mesias','D','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Dapin','J','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Lucero','D','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Mantilla','G','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Camino','J','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Cernal','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Pelayo','R','f','Ms.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Dereal','W','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Dela Peña','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Lim','PJ','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Calungsod','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Adorable','R','f','Doc.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Campos','H','f','Ms.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Bontia','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Sajulga','Y','f','Ms.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Yamba','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Hara','','f','','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Joligon','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Rulona','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Sinday','J','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Mesias','N','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Medina','N','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Nuñez','A','f','Doc.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Mundiz','FP','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Morata','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Surita','R','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Lafuente','','f','Mr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Sario','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Sabelino','J','f','Doc.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Almazan','','f','Prof.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Abellanosa Jr.','A','f','Engr.','','','','faculty','5','0','default.png','0','customized','nothing','verified'),
        // ('Necio','G','f','Doc.','','','','faculty','5','0','default.png','0','customized','nothing','verified')
        // ")) {
        //     echo "Success";
        // } else {
        //     echo "Fail";
        // }
        // header('location: ../kira');
        // if ($connect->query("CREATE TABLE scheduled_classes_shs(
        //     schedule_id int auto_increment PRIMARY KEY,
        //     teacher int,
        //     course text,
        //     semester int,
        //     subject text,
        //     weekday varchar(10),
        //     start_time int,
        //     end_time int,
        //     schoolyear text,
        //     assigner int,
        //     room int,
        //     schedule_status text,
        //     schedule_process text,
        //     conflict_status text    
        // );")) {
        //     echo "Success";
        // } else {
        //     echo "Fail";
        // }
        if ($connect->query("UPDATE members SET member_salut = 'Ms.' where member_id = '250'")) {
            echo "Success";
        }
    } else {
        header('location: ../kira');
    }
}
