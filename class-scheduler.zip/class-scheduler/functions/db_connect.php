<?php
// $connect = mysqli_connect("localhost", "root", "", "scheduler");
$connect = new mysqli("localhost", "ascblzri_root", "troythesisP@$$", "ascblzri_scheduler");

if (!$connect) {
	header('location: ../error');
}
