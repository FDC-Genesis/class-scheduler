<?php
include('../functions/sessionstart.php');
include('../functions/db_connect.php');

if (isset($_GET['loadunclicked'])) {
    if ($_SESSION['superiority'] !== 'student') {
        $id = $_SESSION['id'];

        $unclicked = mysqli_query($connect, "SELECT * FROM messages where receiver = '$id' and click_status_receiver = 'unclicked' group by sender");
        echo mysqli_num_rows($unclicked);
    } else {
        echo "Wala";
    }
}

if (isset($_POST['click'])) {
    $id = $_SESSION['id'];
    mysqli_query($connect, "UPDATE `messages` SET `click_status_receiver`='clicked' WHERE receiver = '$id'");
}

if (isset($_GET['chatlists'])) {

    $id = $_SESSION['id'];
    $resultArr = [];
    $contacted = [];
    $queryAsSender = mysqli_query($connect, "SELECT max(messages.message_id) as id FROM messages join members where messages.receiver = members.member_id and sender = '$id' group by receiver order by message_id desc;");


    while ($row = mysqli_fetch_assoc($queryAsSender)) {
        $idOfRecentMsg = $row['id'];

        $userAsSender = mysqli_query($connect, "SELECT messages.message_id as message_id, messages.sender as sender, messages.receiver as receiver, messages.content as content, messages.message_status_receiver as message_status_receiver, messages.message_status_sender as message_status_sender, messages.click_status_receiver as click_status_receiver, messages.click_status_sender as click_status_sender, messages.date_sent as date_sent, concat(members.member_first, ' ', members.member_last) as name, members.imgname as imgname FROM messages join members where messages.receiver = members.member_id and messages.message_id = '$idOfRecentMsg' and sender = '$id' group by receiver order by message_id desc");

        while ($rowsingle = mysqli_fetch_assoc($userAsSender)) {
            if (!in_array($rowsingle['receiver'], $contacted)) {
                // verifier
                $contactedid = $rowsingle['receiver'];
                array_push($contacted, $contactedid);

                // latest content
                $sender = $connect->query("SELECT max(message_id) as id from messages where sender = '$contactedid' and receiver = '$id'")->fetch_assoc();
                $sender = (int)($sender['id']);
                $receiver = $connect->query("SELECT max(message_id) as id from messages where receiver = '$contactedid' and sender = '$id'")->fetch_assoc();
                $receiver = (int)($receiver['id']);

                if ($sender > $receiver) {
                    $latestContent = $connect->query("SELECT content from messages where message_id = '$sender'")->fetch_assoc();
                    $latestContent = $latestContent['content'];
                } else {
                    $latestContent = $connect->query("SELECT content from messages where message_id = '$receiver'")->fetch_assoc();
                    $latestContent = 'You: ' . $latestContent['content'];
                }

                $rowsingle['latest_content'] = $latestContent;

                // image of contacted
                $imgcontacted = mysqli_query($connect, "SELECT imgname from members where member_id = '$contactedid'")->fetch_assoc();
                $rowsingle['contactedimg'] = $imgcontacted['imgname'];

                // push all $rowsingle
                array_push($resultArr, $rowsingle);
            }
        }
    }

    $queryAsReceiver = mysqli_query($connect, "SELECT max(messages.message_id) as id FROM messages join members where messages.sender = members.member_id and receiver = '$id' group by sender order by message_id desc;");

    while ($row = mysqli_fetch_assoc($queryAsReceiver)) {
        $idOfRecentMsg = $row['id'];

        $userAsReceiver = mysqli_query($connect, "SELECT messages.message_id as message_id, messages.sender as sender, messages.receiver as receiver, messages.content as content, messages.message_status_receiver as message_status_receiver, messages.message_status_sender as message_status_sender, messages.click_status_receiver as click_status_receiver, messages.click_status_sender as click_status_sender, messages.date_sent as date_sent, concat(members.member_first, ' ', members.member_last) as name, members.imgname as imgname FROM messages join members where messages.sender = members.member_id and messages.message_id = '$idOfRecentMsg' and receiver = '$id' group by sender order by message_id desc");

        while ($rowsingle = mysqli_fetch_assoc($userAsReceiver)) {
            if (!in_array($rowsingle['sender'], $contacted)) {
                // verifier
                $contactedid = $rowsingle['sender'];
                array_push($contacted, $contactedid);

                // latest content
                $sender = $connect->query("SELECT max(message_id) as id from messages where sender = '$contactedid' and receiver = '$id'")->fetch_assoc();
                $sender = (int)($sender['id']);
                $receiver = $connect->query("SELECT max(message_id) as id from messages where receiver = '$contactedid' and sender = '$id'")->fetch_assoc();
                $receiver = (int)($receiver['id']);

                if ($sender > $receiver) {
                    $latestContent = $connect->query("SELECT content from messages where message_id = '$sender'")->fetch_assoc();
                    $latestContent = $latestContent['content'];
                } else {
                    $latestContent = $connect->query("SELECT content from messages where message_id = '$receiver'")->fetch_assoc();
                    $latestContent = 'You: ' . $latestContent['content'];
                }

                $rowsingle['latest_content'] = $latestContent;

                // image of contacted
                $imgcontacted = mysqli_query($connect, "SELECT imgname from members where member_id = '$contactedid'")->fetch_assoc();
                $rowsingle['contactedimg'] = $imgcontacted['imgname'];
                array_push($resultArr, $rowsingle);
            }
        }
    }

    echo json_encode($resultArr);
}

/*if (isset($_POST['maxidConvo'])) {
    $convowith = $_POST['maxidConvo'];
    $self = $_SESSION['id'];

    $sender = $connect->query("SELECT max(message_id) as id from messages where sender = '$convowith' and receiver = '$self'")->fetch_assoc();
    $sender = (int)($sender['id']);

    $receiver = $connect->query("SELECT max(message_id) as id from messages where receiver = '$convowith' and sender = '$self'")->fetch_assoc();
    $receiver = (int)($receiver['id']);
    if ($sender > $receiver) {
        $maxId = $connect->query("SELECT content from messages where message_id = '$sender'")->fetch_assoc();
        $maxId = $maxId['content'];
    } else {
        $maxId = $connect->query("SELECT content from messages where message_id = '$receiver'")->fetch_assoc();
        $maxId = 'You: ' . $maxId['content'];
    }

    echo $maxId;
}*/

if (isset($_GET['unreads'])) {
    $convowith = $_GET['unreads'];
    $id = $_GET['id'];
    $query = mysqli_query($connect, "SELECT * from messages where sender = '$convowith' and receiver = '$id' and message_status_receiver = 'unread'");

    echo mysqli_num_rows($query);
}

if (isset($_GET['getconvos'])) {
    $contact = $_GET['getconvos'];
    $user = $_GET['id'];

    $userAsReceiver = mysqli_query($connect, "SELECT messages.message_id as message_id, messages.sender as sender, messages.receiver as receiver, messages.content as content, messages.message_status_receiver as message_status_receiver, messages.message_status_sender as message_status_sender, messages.click_status_receiver as click_status_receiver, messages.click_status_sender as click_status_sender, messages.date_sent as date_sent, concat(members.member_first, ' ', members.member_last) as name, members.imgname as imgname FROM messages join members where messages.sender = members.member_id and messages.receiver = '$user' and messages.sender = '$contact' order by messages.message_id desc");

    $userAsSender = mysqli_query($connect, "SELECT messages.message_id as message_id, messages.sender as sender, messages.receiver as receiver, messages.content as content, messages.message_status_receiver as message_status_receiver, messages.message_status_sender as message_status_sender, messages.click_status_receiver as click_status_receiver, messages.click_status_sender as click_status_sender, messages.date_sent as date_sent, concat(members.member_first, ' ', members.member_last) as name, members.imgname as imgname FROM messages join members where messages.receiver = members.member_id and messages.sender = '$user' and messages.receiver = '$contact' order by messages.message_id desc");

    $resultArr = [];

    while ($row = mysqli_fetch_assoc($userAsReceiver)) {
        array_push($resultArr, $row);
    }

    while ($row = mysqli_fetch_assoc($userAsSender)) {
        array_push($resultArr, $row);
    }

    mysqli_query($connect, "UPDATE `messages` SET `message_status_receiver`='read', `click_status_receiver`='clicked' WHERE receiver = '$user' and sender = '$contact'");

    echo json_encode($resultArr);

    // $inserted = 0;
}
